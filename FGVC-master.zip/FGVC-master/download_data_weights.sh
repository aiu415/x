
wget --no-check-certificate https://filebox.ece.vt.edu/~chengao/FGVC/data.zip
unzip data.zip
rm data.zip

wget --no-check-certificate https://filebox.ece.vt.edu/~chengao/FGVC/weight.zip
unzip weight.zip
rm weight.zip
